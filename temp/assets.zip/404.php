<?php include("templates/header.php"); ?>

<main id="main">

  <br>
  <!-- ======= Portfolio Details Section ======= -->
  <section id="portfolio-details" class="portfolio-details">
    <div class="container">

      <div class="row gy-4">

        <div class="col-lg-7">
          <img src="assets/img/404.png" class="img-fluid animated" alt="">
        </div>
        <div class="col-lg-5 d-flex justify-content-center align-items-center">
          <div>
            <h2>Parece que esta página no existe.</h2>
            <p>Esta página no está disponible. Disculpa las molestias. Prueba a realizar otra búsqueda.</p>
          </div>
        </div>
      </div>

    </div>

    </div>
  </section><!-- End Portfolio Details Section -->

</main><!-- End #main -->
<?php include("templates/footer.php"); ?>