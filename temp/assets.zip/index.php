<?php include("templates/header.php"); ?>
<?php 
$sentencia = $conn->prepare("SELECT id,titulo,foto,fecha FROM `registro` 
ORDER BY `registro`.`fecha` DESC LIMIT 3");
$sentencia->execute();
$lista_blogs = $sentencia->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">

  <div class="container">
    <div class="row">
      <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
        <div class="animated-text">
          <h1>Biotecnología para la</h1>
          <h1>conservación de la naturaleza</h1>
          <h2>Sé parte del movimiento de ciencia y tecnología para la naturaleza.</h2>
        </div>
        <div class="d-flex">
          <a href="#contact" class="btn-get-started scrollto">Contactanos</a>
          <a href="https://www.youtube.com/watch?v=Gr9VUnqABfc" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Video</span></a>
        </div>
      </div>
      <div class="col-lg-6 order-1 order-lg-2 hero-img">
        <img src="assets/img/hero-img.webp" class="img-fluid animated" alt="hero" loading="lazy">
      </div>
    </div>
  </div>

</section><!-- End Hero -->

<main id="main">

  <!-- ======= About Section ======= -->
  <section id="about" class="about">
    <div class="container">

      <div class="row">
        <div class="col-lg-6">
          <img src="assets/img/about.webp" class="img-fluid" alt="about" loading="lazy">
        </div>
        <div class="col-lg-6 pt-4 pt-lg-0 content">
          <h3>Biotecnología, sostenibilidad y desarrollo</h3>
          <p class="fst-italic">
            Foreslab se dedica a la producción masiva de plantas nativas forestales,
            frutales y ornamentales, haciendo uso de la biotecnología vegetal para
            facilitar diversidad genética nativa para hacer frente a la falta de abastecimiento
            para procesos de reforestación, restauración ecológica, compensación ambiental y
            actividades productivas sostenibles.
          </p>
          <h4>Por que elegirnos</h4>
          <ul>
            <li><i class="bi bi-check-circle"></i> Experiencia y conocimiento técnico</li>
            <li><i class="bi bi-check-circle"></i> Personalización de servicios</li>
            <li><i class="bi bi-check-circle"></i> Uso de procesos ecológicos</li>
          </ul>
          <p>
            La empresa se enfoca en el uso responsable y ético de la biotecnología,
            logrando una atención personalizada al cliente en función de sus necesidades.
            Por lo que podemos brindar servicios a diferentes Instituciones públicas y privadas,
            asociaciones, proyectos de inversión, comunidades y sociedad civil.
          </p>
        </div>
      </div>

    </div>
  </section><!-- End About Section -->

  <!-- ======= Featured Services Section ======= -->
  <section id="featured-services" class="featured-services">
    <div class="container">



      <div class="row">
        <div class="col-lg-3 col-md-6">
          <div class="icon-box text-center">
            <div class="icon"><i class="bx bx-stopwatch"></i></div>
            <!--<h4 class="title"><a href="">Empresa Privada</a></h4>-->
            <p class="description">Aumento de la velocidad de crecimiento</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mt-4 mt-md-0">
          <div class="icon-box text-center">
            <div class="icon"><i class="bx bx-trending-up"></i></div>
            <!--<h4 class="title"><a href="">Asociaciones Forestales</a></h4>-->
            <p class="description">Coeficientes de multiplicación superior</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
          <div class="icon-box text-center">
            <div class="icon"><i class="bx bx-spa"></i></div>
            <!--<h4 class="title"><a href="">Instituciones Publicas</a></h4>-->
            <p class="description">Calidad fitosanitaria y agronómica</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
          <div class="icon-box text-center">
            <div class="icon"><i class="bx bx-dna"></i></div>
            <!--<h4 class="title"><a href="">ONG's</a></h4>-->
            <p class="description">Garantiza identidad genetica</p>
          </div>
        </div>
      </div>

    </div>
  </section><!-- End Featured Services Section -->
  <br>
  <!-- ======= Counts Section ======= -->
  <section id="counts" class="counts">
    <div class="container">

      <div class="row counters">

        <div class="col-lg-3 col-6 text-center">
          <span data-purecounter-start="0" data-purecounter-end="4" data-purecounter-duration="1" class="purecounter"></span>
          <p>Especies en producción</p>
        </div>

        <div class="col-lg-3 col-6 text-center">
          <span data-purecounter-start="0" data-purecounter-end="10" data-purecounter-duration="1" class="purecounter"></span>
          <p>Investigaciones activas</p>
        </div>

        <div class="col-lg-3 col-6 text-center">
          <span data-purecounter-start="0" data-purecounter-end="2" data-purecounter-duration="1" class="purecounter"></span>
          <p>Convenios de investigación</p>
        </div>

        <div class="col-lg-3 col-6 text-center">
          <span data-purecounter-start="0" data-purecounter-end="6" data-purecounter-duration="1" class="purecounter"></span>
          <p>Alianzas estratégicas</p>
        </div>

      </div>

    </div>
  </section><!-- End Counts Section -->


  <!-- ODS section -->
  <section>
    <div class="container " data-aos="fade-up">
      <div class="ods text-center">
        <blockquote class="blockquote">
          <p class="pb-3">
            <i class="fas fa-quote-left fa-xs text-success"></i>
            <span class="lead font-italic">Nuestra empresa contribuye con los siguientes 
              <a href="https://www.un.org/sustainabledevelopment/es/objetivos-de-desarrollo-sostenible/">ODS's</a></span>
            <i class="fas fa-quote-right fa-xs text-success"></i>
          </p>
        </blockquote>
        <ul>
          <li>
            <a href="https://www.un.org/sustainabledevelopment/es/climate-change-2/" target="_blank">
              <img src="/assets/img/ods13.webp" alt="ods13" loading="lazy">
            </a>
          </li>
          <li>
            <a href="https://www.un.org/sustainabledevelopment/es/biodiversity/" target="_blank">
              <img src="/assets/img/ods15.webp" alt="ods15" loading="lazy">
            </a>
          </li>
          <li>
            <a href="https://www.un.org/sustainabledevelopment/es/cities/" target="_blank">
              <img src="/assets/img/ods11.webp" alt="ods11" loading="lazy">
            </a>
          </li>
        </ul>
      </div>

    </div>
  </section><!-- end ODS -->

  </div>
  <?php include("templates/products.php"); ?>

  <?php include("templates/services.php"); ?>



  <!-- ======= Clients Section ======= -->
  <section>
    <div class="container" data-aos="fade-up">
      <div class="row justify-content-md-center">
        <div class="col-lg-6 text-center">
          <blockquote class="blockquote">
            <p class="pb-3">
              <i class="fas fa-quote-left fa-xs text-success"></i>
              <span class="lead font-italic">Nuestro negocio se apoya en alianzas sólidas con empresas líderes en la
                industria, lo que nos permite ofrecer soluciones innovadoras de alta calidad a nuestros clientes.</span>
              <i class="fas fa-quote-right fa-xs text-success"></i>
            </p>
          </blockquote>
        </div>
      </div>

      <div class="client text-center">
        <ul>
          <li>
            <a href="https://www.ronap.com.pe/" target="_blank">
              <img src="assets/img/clients/Ronap.webp" alt="client1" loading="lazy">
              <img src="assets/img/clients/Ronap.webp" alt="client1" loading="lazy">
            </a>
          </li>
          <li>
            <a href="https://incubagraria.lamolina.edu.pe/" target="_blank">
              <img src="assets/img/clients/incubagraria.webp" alt="client2" loading="lazy">
              <img src="assets/img/clients/incubagraria.webp" alt="client2" loading="lazy">
            </a>
          </li>
          <li>
            <a href="https://www.caminoverdetambopata.org/" target="_blank">
              <img src="assets/img/clients/CaminoVerde.webp" alt="client3">
              <img src="assets/img/clients/CaminoVerde.webp" alt="client3">
            </a>
          </li>
        </ul>
      </div>

    </div>
  </section>
  <!-- End Clients Section -->


  <!-- ======= Cta Section ======= -->
  <section id="cta" class="cta">
    <div class="container">

      <div class="text-center">
        <h3>Novedades</h3>
        <p> ¡No se pierda nuestras últimas novedades!
          Visite nuestro blog para conocer los avances en biotecnología.
          Descubra cómo estamos transformando la industria con soluciones
          personalizadas para nuestros clientes. ¡Manténgase actualizado con Foreslab!</p>
        <a class="cta-btn" href="blog">Visita nuestro Blog</a>
      </div>
      <!-- ======= Recent Blog Posts Section ======= -->
      <section id="recent-blog-posts" class="recent-blog-posts">

        <div class="container" data-aos="fade-up">

          <div class="row">
          <?php foreach ($lista_blogs as $blogs) { ?>

            <div class="col-lg-4">
              <div class="post-box">
                <div class="post-img"><img src="assets/img/blog/<?php echo $blogs["foto"]; ?>" class="img-fluid" alt="blogs" loading="lazy"></div>
                <span class="post-date"><?php echo $blogs["fecha"]; ?></span>
                <h3 class="post-title"><?php echo $blogs["titulo"]; ?></h3>
                <div class="post-read"><a href="blog/post.php?pubID=<?php echo $blogs["id"];?>" 
                class="readmore stretched-link mt-auto">
                    <span>Leer mas</span><i class="bi bi-arrow-right"></i></a></div>
              </div>
            </div>
            <?php } ?>
          </div>

        </div>

      </section><!-- End Recent Blog Posts Section -->



    </div>
  </section>


  <!-- End Cta Section -->


  <!-- ======= Contact Section ======= -->
  <section id="contact" class="contact">
    <div class="container">

      <div class="section-title">
        <span>Contactanos</span>
        <h2>Contactanos</h2>
        <p>Para obtener mas información de nuestros <b>servicios o productos</b> <br>
          escribanos a través de este formulario o los datos de contacto.</p>
      </div>
      <div class="cotainer-fluid">
        <div class="row d-flex">
          <div class="col-lg-6 d-flex align-items-stretch">
            <div class="info d-flex">
              <div class="row">
                <div class="col-md-6">
                  <div class="address">
                    <div class="icon-box">
                      <i class="bi bi-geo-alt"></i>
                      <h3>Trabajamos:</h3>
                      <p>Madre de Dios, Amazonas, Ucayali,<br>San Martín, Cusco.</p>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="phone">
                    <div class="icon-box">
                      <i class="bi bi-telephone"></i>
                      <h3>Telefonos</h3>
                      <p>+51 985 153 678<br>+51 902 295 669</p>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="email">
                    <div class="icon-box">
                      <i class="bi bi-envelope"></i>
                      <h3>Correos</h3>
                      <p>info@foreslab.com<br>ventas@foreslab.com</p>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="address">
                    <div class="info-box">
                      <i class="bi bi-clock"></i>
                      <h3> Atención</h3>
                      <p>Lunes - Viernes<br>9:00 am - 05:00 pm</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
           
            <form action="https://formspree.io/f/xpzejdrn" method="POST" class="php-email-form" target="_blank">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Nombres y Apellidos" required>
                </div>

                <div class="col-md-6 ">
                  <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="subject" placeholder="Asunto" required>
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Mensaje" required></textarea>
                </div>

                <div class="col-md-12 text-center">
                  <div class="loading">Cargando</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Tu mensaje fue enviado.
                    Gracias por comunicarte con Foreslab!</div>
                  <button type="submit">Enviar Mensaje</button>
                </div>

              </div>
            </form>

          </div>

        </div>

      </div>
    </div>
    </div>
  </section><!-- End Contact Section -->

</main><!-- End #main -->

<?php include("templates/footer.php"); ?>